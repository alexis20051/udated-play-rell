# PlayReel — Full-Stack Movie Streaming Platform

PlayReel is a modern full-stack movie / video / photo / music streaming platform.

- **Frontend:** React + Vite (JSX only), Redux Toolkit, Tailwind CSS, Framer Motion, Socket.io-client, React Router, Axios, React Hot Toast, React Icons
- **Backend:** Node.js + Express + MongoDB (Mongoose) + JWT + Multer + Cloudinary + Socket.io

## Folder Structure

```
playreel/
├── frontend/   # React + Vite (.jsx)
└── backend/    # Node + Express + MongoDB
```

## Quick Start

### 1. Backend

```bash
cd backend
cp .env.example .env   # edit values
npm install
npm run seed           # creates default admin
npm run dev
```

Backend runs on **http://localhost:5000**.

Default admin (auto-seeded):

- Email: `admin@playreel.com`
- Password: `Admin@123`

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend runs on **http://localhost:5173**.

## Features

### Public (no login)
- Watch movies / videos, view photos, listen to music
- Browse categories, search, view trending / latest / featured
- Like, comment, share
- Contact admin + send feedback
- Real-time chat with admin (Socket.io)

### Admin
- Single admin account (cannot register publicly)
- Login, forgot/change password, update profile + photo
- Upload / edit / delete movies, videos, photos, music (local or Cloudinary)
- Manage users, comments, messages, feedback
- Dashboard analytics + notifications
- Real-time chat replies

### Uploads
Supports both **local uploads** (stored in `backend/uploads/`) and **Cloudinary URLs**. Both play correctly in the player.

## Environment Variables (backend/.env)

```
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/playreel
JWT_SECRET=change_me_to_a_long_random_string
CLIENT_URL=http://localhost:5173

# Optional Cloudinary
CLOUDINARY_CLOUD_NAME=
CLOUDINARY_API_KEY=
CLOUDINARY_API_SECRET=

# Default admin
ADMIN_EMAIL=admin@playreel.com
ADMIN_PASSWORD=Admin@123
```

## Contact

- Email: alexisnzayisingiza@gmail.com
- Phone: 0781953024

> Follow Alexis Nzayisigiza for software development services, website creation, mobile apps, and technology consulting.
