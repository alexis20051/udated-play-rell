/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#fff1f3',
          100: '#ffe1e6',
          400: '#ff5c7a',
          500: '#ff2e57',
          600: '#e11d3c',
          700: '#b8152f',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['"Space Grotesk"', 'Inter', 'sans-serif'],
      },
      backgroundImage: {
        'hero-gradient':
          'radial-gradient(60% 80% at 20% 10%, rgba(255,46,87,0.35) 0%, rgba(0,0,0,0) 60%), radial-gradient(50% 60% at 90% 30%, rgba(124,58,237,0.35) 0%, rgba(0,0,0,0) 60%)',
      },
    },
  },
  plugins: [],
};
