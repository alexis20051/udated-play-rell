import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || '';

const API = axios.create({
  baseURL: `${API_BASE}/api`,
});

API.interceptors.request.use((config) => {
  const token = localStorage.getItem('playreel_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Build a fully-qualified URL for any media item.
// - Cloudinary / external URLs are returned untouched.
// - Local /uploads/... paths are prefixed with the API origin so they work
//   both in dev (via Vite proxy) and in production (direct backend).
export const mediaUrl = (url) => {
  if (!url) return '';
  if (/^https?:\/\//i.test(url)) return url;
  if (url.startsWith('/uploads')) return `${API_BASE}${url}`;
  if (url.startsWith('uploads/')) return `${API_BASE}/${url}`;
  return url;
};

export default API;
