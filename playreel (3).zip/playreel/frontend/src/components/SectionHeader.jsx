import React from 'react';
import { Link } from 'react-router-dom';

export default function SectionHeader({ title, subtitle, link, linkLabel = 'See all' }) {
  return (
    <div className="flex items-end justify-between mb-5">
      <div>
        <h2 className="section-title">{title}</h2>
        {subtitle && <p className="text-sm text-neutral-400 mt-1">{subtitle}</p>}
      </div>
      {link && (
        <Link to={link} className="text-sm text-brand-400 hover:text-brand-300 font-medium">
          {linkLabel} →
        </Link>
      )}
    </div>
  );
}
