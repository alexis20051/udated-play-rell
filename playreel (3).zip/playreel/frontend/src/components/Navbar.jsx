import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiMenu, FiX, FiSearch, FiSun, FiMoon, FiUpload } from 'react-icons/fi';
import { useTheme } from '../context/ThemeContext.jsx';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/movies', label: 'Movies' },
  { to: '/videos', label: 'Videos' },
  { to: '/photos', label: 'Photos' },
  { to: '/music', label: 'Music' },
  { to: '/trending', label: 'Trending' },
  { to: '/categories', label: 'Categories' },
  { to: '/contact', label: 'Contact' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const navigate = useNavigate();
  const { theme, toggle } = useTheme();

  const submit = (e) => {
    e.preventDefault();
    if (q.trim()) navigate(`/search?q=${encodeURIComponent(q.trim())}`);
  };

  return (
    <motion.header
      initial={{ y: -30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="sticky top-0 z-50 glass border-b border-white/10"
    >
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
        <Link to="/" className="font-display text-2xl font-bold flex items-center gap-2">
          <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-purple-600 grid place-items-center">▶</span>
          <span>
            <span className="bg-gradient-to-r from-brand-500 to-purple-500 bg-clip-text text-transparent">Play</span>Reel
          </span>
        </Link>

        <nav className="hidden lg:flex items-center gap-1 ml-4">
          {navLinks.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === '/'}
              className={({ isActive }) =>
                `px-3 py-2 rounded-lg text-sm font-medium transition ${
                  isActive ? 'text-white bg-white/10' : 'text-neutral-300 hover:text-white hover:bg-white/5'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        <form onSubmit={submit} className="hidden md:flex flex-1 max-w-md ml-auto relative">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search movies, videos, photos…"
            className="input pl-9"
          />
        </form>

        <button onClick={toggle} className="btn-ghost !p-2.5" title="Toggle theme">
          {theme === 'dark' ? <FiSun /> : <FiMoon />}
        </button>

        <Link to="/upload" className="btn-ghost hidden md:inline-flex">
          <FiUpload /> Upload
        </Link>

        <Link to="/admin/login" className="btn-primary hidden md:inline-flex">
          Admin
        </Link>

        <button className="lg:hidden btn-ghost !p-2.5" onClick={() => setOpen((v) => !v)}>
          {open ? <FiX /> : <FiMenu />}
        </button>
      </div>

      {open && (
        <motion.div
          initial={{ height: 0 }}
          animate={{ height: 'auto' }}
          className="lg:hidden border-t border-white/10 overflow-hidden"
        >
          <div className="px-4 py-3 flex flex-col gap-1">
            {navLinks.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === '/'}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `px-3 py-2 rounded-lg text-sm font-medium ${isActive ? 'bg-white/10' : 'hover:bg-white/5'}`
                }
              >
                {l.label}
              </NavLink>
            ))}
            <form onSubmit={submit} className="relative mt-2">
              <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search…" className="input pl-9" />
            </form>
            <div className="flex gap-2 mt-2">
              <Link to="/upload" onClick={() => setOpen(false)} className="btn-ghost flex-1 justify-center">Upload</Link>
              <Link to="/admin/login" onClick={() => setOpen(false)} className="btn-primary flex-1 justify-center">Admin</Link>
            </div>
          </div>
        </motion.div>
      )}
    </motion.header>
  );
}
