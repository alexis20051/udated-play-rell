import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiPlay, FiHeart, FiEye } from 'react-icons/fi';
import { mediaUrl } from '../services/api.js';

export default function MediaCard({ item, type = 'movies', large = false }) {
  const thumb = mediaUrl(item.thumbnail || item.image || item.cover || item.banner);
  return (
    <motion.div
      whileHover={{ y: -4 }}
      className={`card group relative ${large ? 'aspect-[16/10]' : 'aspect-[3/4]'}`}
    >
      <Link to={`/${type}/${item._id}`} className="block w-full h-full">
        {thumb ? (
          <img
            src={thumb}
            alt={item.title}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-brand-500/30 to-purple-600/30 grid place-items-center">
            <FiPlay className="text-5xl text-white/70" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-90" />
        <div className="absolute bottom-0 left-0 right-0 p-3">
          <h3 className="font-semibold text-sm md:text-base line-clamp-1">{item.title}</h3>
          <div className="flex items-center gap-3 text-xs text-neutral-300 mt-1">
            {typeof item.views === 'number' && <span className="flex items-center gap-1"><FiEye /> {item.views}</span>}
            {typeof item.likes === 'number' && <span className="flex items-center gap-1"><FiHeart /> {item.likes}</span>}
            {item.category && <span className="px-2 py-0.5 rounded-full bg-white/10">{item.category}</span>}
          </div>
        </div>
        <div className="absolute top-2 right-2 w-9 h-9 rounded-full bg-brand-500/90 grid place-items-center opacity-0 group-hover:opacity-100 transition">
          <FiPlay className="text-white" />
        </div>
      </Link>
    </motion.div>
  );
}
