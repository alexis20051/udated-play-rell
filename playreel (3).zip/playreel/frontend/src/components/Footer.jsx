import React from 'react';
import { Link } from 'react-router-dom';
import { FaFacebook, FaInstagram, FaWhatsapp, FaXTwitter, FaYoutube, FaLinkedin } from 'react-icons/fa6';
import { FiMail, FiPhone } from 'react-icons/fi';

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-white/10 glass">
      <div className="max-w-7xl mx-auto px-4 py-12 grid md:grid-cols-4 gap-8">
        <div>
          <div className="font-display text-2xl font-bold mb-3">
            <span className="bg-gradient-to-r from-brand-500 to-purple-500 bg-clip-text text-transparent">Play</span>Reel
          </div>
          <p className="text-sm text-neutral-400">
            Stream movies, videos, photos and music — anywhere, anytime. A premium experience built for creators and fans.
          </p>
        </div>

        <div>
          <h4 className="font-semibold mb-3">Explore</h4>
          <ul className="space-y-2 text-sm text-neutral-400">
            <li><Link to="/movies" className="hover:text-brand-400">Movies</Link></li>
            <li><Link to="/videos" className="hover:text-brand-400">Videos</Link></li>
            <li><Link to="/photos" className="hover:text-brand-400">Photos</Link></li>
            <li><Link to="/music" className="hover:text-brand-400">Music</Link></li>
            <li><Link to="/trending" className="hover:text-brand-400">Trending</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold mb-3">Contact</h4>
          <ul className="space-y-2 text-sm text-neutral-400">
            <li className="flex items-center gap-2"><FiMail /> alexisnzayisingiza@gmail.com</li>
            <li className="flex items-center gap-2"><FiPhone /> 0781953024</li>
          </ul>
          <div className="flex gap-3 mt-4 text-xl">
            <a href="#" className="hover:text-brand-400"><FaFacebook /></a>
            <a href="#" className="hover:text-brand-400"><FaInstagram /></a>
            <a href="https://wa.me/250781953024" className="hover:text-brand-400"><FaWhatsapp /></a>
            <a href="#" className="hover:text-brand-400"><FaXTwitter /></a>
            <a href="#" className="hover:text-brand-400"><FaYoutube /></a>
            <a href="#" className="hover:text-brand-400"><FaLinkedin /></a>
          </div>
        </div>

        <div>
          <h4 className="font-semibold mb-3">About</h4>
          <p className="text-sm text-neutral-400">
            Follow <span className="text-white font-semibold">Alexis Nzayisigiza</span> for software development services,
            website creation, mobile apps, and technology consulting.
          </p>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-sm text-neutral-500">
        © {new Date().getFullYear()} PlayReel. All rights reserved.
      </div>
    </footer>
  );
}
