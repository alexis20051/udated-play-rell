import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiMessageCircle, FiX, FiSend } from 'react-icons/fi';
import API from '../services/api.js';
import socket from '../services/socket.js';
import { getSessionId, getGuestName, setGuestName } from '../utils/session.js';

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [name, setName] = useState(getGuestName());
  const sessionId = useRef(getSessionId()).current;
  const endRef = useRef(null);

  useEffect(() => {
    socket.emit('join', { sessionId });
    const onMsg = (m) => {
      if (m.sessionId === sessionId) setMessages((prev) => [...prev, m]);
    };
    socket.on('chat:message', onMsg);
    return () => socket.off('chat:message', onMsg);
  }, [sessionId]);

  useEffect(() => {
    if (!open) return;
    API.get(`/chats/${sessionId}`).then(({ data }) => setMessages(data)).catch(() => {});
  }, [open, sessionId]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, open]);

  const send = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    setGuestName(name || 'Guest');
    socket.emit('chat:message', { sessionId, sender: 'user', name: name || 'Guest', text: text.trim() });
    setText('');
  };

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen((v) => !v)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-gradient-to-br from-brand-500 to-purple-600 shadow-2xl shadow-brand-500/40 grid place-items-center text-white text-2xl"
      >
        {open ? <FiX /> : <FiMessageCircle />}
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            className="fixed bottom-24 right-6 z-40 w-[92vw] max-w-sm h-[480px] glass rounded-2xl flex flex-col overflow-hidden shadow-2xl"
          >
            <div className="p-4 bg-gradient-to-r from-brand-500/30 to-purple-600/30 border-b border-white/10">
              <div className="font-display font-bold">Chat with PlayReel</div>
              <p className="text-xs text-neutral-300">We usually reply within minutes</p>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {messages.length === 0 && (
                <p className="text-center text-sm text-neutral-400 mt-10">Say hi — we're online 👋</p>
              )}
              {messages.map((m) => (
                <div
                  key={m._id || m.createdAt + m.text}
                  className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm ${
                    m.sender === 'user'
                      ? 'ml-auto bg-gradient-to-br from-brand-500 to-purple-600 text-white'
                      : 'bg-white/10'
                  }`}
                >
                  {m.text}
                </div>
              ))}
              <div ref={endRef} />
            </div>
            <form onSubmit={send} className="p-3 border-t border-white/10 flex gap-2">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                className="input !py-2 w-28 text-xs"
              />
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type a message…"
                className="input !py-2 flex-1 text-sm"
              />
              <button className="btn-primary !p-2.5"><FiSend /></button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
