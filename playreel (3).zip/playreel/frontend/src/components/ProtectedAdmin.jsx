import React from 'react';
import { Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

export default function ProtectedAdmin({ children }) {
  const token = useSelector((s) => s.auth.token);
  const user = useSelector((s) => s.auth.user);
  if (!token || user?.role !== 'admin') return <Navigate to="/admin/login" replace />;
  return children;
}
