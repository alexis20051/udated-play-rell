import React from 'react';
import { mediaUrl } from '../services/api.js';

/**
 * Universal player — handles video, audio, image, and HTTP(S) or local /uploads URLs.
 */
export default function Player({ src, type = 'video', poster, className = '' }) {
  const url = mediaUrl(src);
  if (!url) {
    return (
      <div className={`grid place-items-center bg-black/40 rounded-2xl ${className}`}>
        <p className="text-neutral-500">No media available</p>
      </div>
    );
  }
  if (type === 'image') {
    return <img src={url} alt="" className={`w-full rounded-2xl ${className}`} />;
  }
  if (type === 'audio') {
    // ignore aspect-video class for audio
    return (
      <div className="glass rounded-2xl p-6 flex items-center gap-4">
        {poster && (
          <img src={mediaUrl(poster)} alt="" className="w-20 h-20 rounded-xl object-cover" />
        )}
        <audio src={url} controls autoPlay className="w-full" />
      </div>
    );
  }
  return (
    <video
      src={url}
      poster={mediaUrl(poster)}
      controls
      playsInline
      className={`w-full rounded-2xl bg-black ${className}`}
    />
  );
}
