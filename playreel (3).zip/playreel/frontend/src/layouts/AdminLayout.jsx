import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../redux/slices/authSlice.js';
import {
  FiGrid, FiFilm, FiVideo, FiImage, FiMusic, FiUsers,
  FiMail, FiMessageSquare, FiMessageCircle, FiUser, FiLogOut,
} from 'react-icons/fi';

const links = [
  { to: '/admin', icon: FiGrid, label: 'Dashboard', end: true },
  { to: '/admin/movies', icon: FiFilm, label: 'Movies' },
  { to: '/admin/videos', icon: FiVideo, label: 'Videos' },
  { to: '/admin/photos', icon: FiImage, label: 'Photos' },
  { to: '/admin/music', icon: FiMusic, label: 'Music' },
  { to: '/admin/users', icon: FiUsers, label: 'Users' },
  { to: '/admin/messages', icon: FiMail, label: 'Messages' },
  { to: '/admin/chats', icon: FiMessageCircle, label: 'Chats' },
  { to: '/admin/comments', icon: FiMessageSquare, label: 'Comments' },
  { to: '/admin/profile', icon: FiUser, label: 'Profile' },
];

export default function AdminLayout() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = useSelector((s) => s.auth.user);

  return (
    <div className="min-h-screen flex bg-neutral-950 text-neutral-100">
      <aside className="w-64 hidden md:flex flex-col glass m-3 rounded-2xl p-4 sticky top-3 h-[calc(100vh-1.5rem)]">
        <div className="font-display text-2xl font-bold mb-6 px-2">
          <span className="bg-gradient-to-r from-brand-500 to-purple-500 bg-clip-text text-transparent">Play</span>Reel
        </div>
        <nav className="flex flex-col gap-1 flex-1">
          {links.map(({ to, icon: Icon, label, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                  isActive ? 'bg-gradient-to-r from-brand-500/30 to-purple-500/20 text-white' : 'text-neutral-400 hover:bg-white/5 hover:text-white'
                }`
              }
            >
              <Icon /> {label}
            </NavLink>
          ))}
        </nav>
        <button
          onClick={() => { dispatch(logout()); navigate('/admin/login'); }}
          className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm hover:bg-white/5 text-neutral-400 hover:text-brand-400"
        >
          <FiLogOut /> Logout
        </button>
      </aside>
      <div className="flex-1 p-4 md:p-6 overflow-x-hidden">
        <header className="glass rounded-2xl px-5 py-3 flex items-center justify-between mb-5">
          <h1 className="font-display text-lg">Welcome back, {user?.name || 'Admin'}</h1>
          <div className="flex items-center gap-3 text-sm">
            <span className="px-3 py-1 rounded-full bg-brand-500/20 text-brand-400">Admin</span>
          </div>
        </header>
        <Outlet />
      </div>
    </div>
  );
}
