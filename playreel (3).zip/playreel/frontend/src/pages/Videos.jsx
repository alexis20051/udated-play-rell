import React from 'react';
import MediaList from './MediaList.jsx';
export default function Videos() { return <MediaList title="Videos" endpoint="/videos" type="videos" large />; }
