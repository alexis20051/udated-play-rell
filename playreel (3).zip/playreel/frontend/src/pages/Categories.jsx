import React, { useEffect, useState } from 'react';
import API from '../services/api.js';
import SectionHeader from '../components/SectionHeader.jsx';

export default function Categories() {
  const [cats, setCats] = useState([]);
  useEffect(() => { API.get('/categories').then(({ data }) => setCats(data)); }, []);
  const fallback = ['Action', 'Drama', 'Comedy', 'Documentary', 'Music', 'Sports', 'Sci-Fi', 'Lifestyle', 'News', 'Animation'];
  const all = cats.length ? cats.map((c) => c.name) : fallback;
  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <SectionHeader title="Categories" subtitle="Discover by topic" />
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {all.map((c) => (
          <div key={c} className="glass rounded-2xl p-6 text-center hover:scale-105 transition cursor-pointer">
            <div className="font-display text-xl font-bold">{c}</div>
            <div className="text-xs text-neutral-400 mt-1">Browse →</div>
          </div>
        ))}
      </div>
    </div>
  );
}
