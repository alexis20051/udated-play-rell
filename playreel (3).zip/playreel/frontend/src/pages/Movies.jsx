import React from 'react';
import MediaList from './MediaList.jsx';
export default function Movies() { return <MediaList title="Movies" endpoint="/movies" type="movies" />; }
