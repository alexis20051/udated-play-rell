import React, { useState } from 'react';
import toast from 'react-hot-toast';
import API from '../services/api.js';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [type, setType] = useState('contact');
  const [loading, setLoading] = useState(false);
  const change = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await API.post(`/${type}`, form);
      toast.success('Message sent! We will reply shortly.');
      setForm({ name: '', email: '', phone: '', subject: '', message: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send');
    } finally {
      setLoading(false);
    }
  };
  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="font-display text-4xl font-bold">Get in touch</h1>
      <p className="text-neutral-400 mt-2">Have a question or feedback? Send a message to PlayReel.</p>

      <div className="mt-6 inline-flex gap-2 glass p-1 rounded-xl">
        {['contact', 'feedback'].map((t) => (
          <button
            key={t}
            onClick={() => setType(t)}
            className={`px-4 py-2 rounded-lg text-sm font-medium capitalize ${type === t ? 'bg-brand-500 text-white' : ''}`}
          >
            {t}
          </button>
        ))}
      </div>

      <form onSubmit={submit} className="glass rounded-2xl p-6 mt-5 grid md:grid-cols-2 gap-4">
        <input className="input md:col-span-1" name="name" value={form.name} onChange={change} placeholder="Your name" required />
        <input className="input md:col-span-1" name="email" type="email" value={form.email} onChange={change} placeholder="Email" required />
        <input className="input md:col-span-1" name="phone" value={form.phone} onChange={change} placeholder="Phone (optional)" />
        <input className="input md:col-span-1" name="subject" value={form.subject} onChange={change} placeholder="Subject" />
        <textarea className="input md:col-span-2 min-h-[140px]" name="message" value={form.message} onChange={change} placeholder="Your message…" required />
        <button disabled={loading} className="btn-primary md:col-span-2 justify-center">
          {loading ? 'Sending…' : `Send ${type}`}
        </button>
      </form>
    </div>
  );
}
