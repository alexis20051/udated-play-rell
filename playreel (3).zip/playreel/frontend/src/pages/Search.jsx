import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import API from '../services/api.js';
import MediaCard from '../components/MediaCard.jsx';
import SectionHeader from '../components/SectionHeader.jsx';

export default function Search() {
  const [params] = useSearchParams();
  const q = params.get('q') || '';
  const [data, setData] = useState({ movies: [], videos: [], photos: [], music: [] });
  useEffect(() => {
    if (!q) return;
    Promise.all([
      API.get('/movies', { params: { q } }),
      API.get('/videos', { params: { q } }),
      API.get('/photos', { params: { q } }),
      API.get('/music', { params: { q } }),
    ]).then(([m, v, p, mu]) => setData({ movies: m.data, videos: v.data, photos: p.data, music: mu.data }));
  }, [q]);
  const Section = ({ title, items, type, large }) => (
    items.length > 0 && (
      <div className="mb-10">
        <SectionHeader title={title} />
        <div className={`grid gap-4 ${large ? 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4' : 'grid-cols-2 md:grid-cols-4 lg:grid-cols-6'}`}>
          {items.map((i) => <MediaCard key={i._id} item={i} type={type} large={large} />)}
        </div>
      </div>
    )
  );
  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <h1 className="font-display text-3xl font-bold mb-6">Results for "{q}"</h1>
      <Section title="Movies" items={data.movies} type="movies" />
      <Section title="Videos" items={data.videos} type="videos" large />
      <Section title="Photos" items={data.photos} type="photos" large />
      <Section title="Music" items={data.music} type="music" />
      {Object.values(data).every((a) => !a.length) && q && (
        <p className="text-neutral-400">No results found.</p>
      )}
    </div>
  );
}
