import React from 'react';
import DetailPage from './DetailPage.jsx';
export default function MovieDetail() { return <DetailPage endpoint="/movies" type="movie" mediaKind="video" />; }
