import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { FiPlay, FiArrowRight, FiStar } from 'react-icons/fi';
import { fetchMovies, fetchVideos, fetchPhotos } from '../redux/slices/mediaSlice.js';
import MediaCard from '../components/MediaCard.jsx';
import SectionHeader from '../components/SectionHeader.jsx';
import { mediaUrl } from '../services/api.js';

export default function Home() {
  const dispatch = useDispatch();
  const { movies, videos, photos } = useSelector((s) => s.media);
  const [heroIndex, setHeroIndex] = useState(0);

  useEffect(() => {
    dispatch(fetchMovies({ limit: 20 }));
    dispatch(fetchVideos({ limit: 12 }));
    dispatch(fetchPhotos({ limit: 12 }));
  }, [dispatch]);

  const featured = movies.slice(0, 5);
  useEffect(() => {
    if (!featured.length) return;
    const t = setInterval(() => setHeroIndex((i) => (i + 1) % featured.length), 6000);
    return () => clearInterval(t);
  }, [featured.length]);

  const hero = featured[heroIndex];

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 pt-10 pb-20 grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs mb-5"
            >
              <FiStar className="text-brand-400" /> Premium streaming, reimagined
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 }}
              className="font-display text-4xl md:text-6xl font-bold leading-tight"
            >
              Stream the magic of{' '}
              <span className="bg-gradient-to-r from-brand-500 via-pink-500 to-purple-500 bg-clip-text text-transparent">
                stories, sound & vision
              </span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="mt-5 text-neutral-300 text-lg max-w-xl"
            >
              Movies, videos, photos and music — all in one beautifully crafted home. Upload your own from your PC,
              or stream straight from the cloud. No account required.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="mt-7 flex flex-wrap gap-3"
            >
              <Link to="/movies" className="btn-primary"><FiPlay /> Watch now</Link>
              <Link to="/upload" className="btn-ghost">Upload yours <FiArrowRight /></Link>
            </motion.div>

            <div className="grid grid-cols-3 gap-6 mt-10 max-w-md">
              {[
                { v: `${movies.length}+`, l: 'Movies' },
                { v: `${videos.length}+`, l: 'Videos' },
                { v: `${photos.length}+`, l: 'Photos' },
              ].map((s) => (
                <div key={s.l}>
                  <div className="font-display text-2xl font-bold bg-gradient-to-r from-brand-500 to-purple-500 bg-clip-text text-transparent">{s.v}</div>
                  <div className="text-xs text-neutral-400">{s.l}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative h-[420px]">
            <AnimatePresence mode="wait">
              {hero ? (
                <motion.div
                  key={hero._id}
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.6 }}
                  className="absolute inset-0 rounded-3xl overflow-hidden glass"
                >
                  <img
                    src={mediaUrl(hero.banner || hero.thumbnail)}
                    alt={hero.title}
                    className="w-full h-full object-cover"
                    onError={(e) => (e.currentTarget.style.display = 'none')}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
                  <div className="absolute bottom-5 left-5 right-5">
                    <span className="text-xs px-2 py-1 rounded-full bg-brand-500/30 text-brand-300">Featured</span>
                    <h3 className="font-display text-2xl font-bold mt-2">{hero.title}</h3>
                    <p className="text-sm text-neutral-300 line-clamp-2 mt-1">{hero.description}</p>
                    <Link to={`/movies/${hero._id}`} className="btn-primary mt-4"><FiPlay /> Watch</Link>
                  </div>
                </motion.div>
              ) : (
                <div className="absolute inset-0 rounded-3xl glass grid place-items-center text-neutral-400">
                  No featured content yet
                </div>
              )}
            </AnimatePresence>
            <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
              {featured.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setHeroIndex(i)}
                  className={`h-1.5 rounded-full transition-all ${i === heroIndex ? 'w-6 bg-brand-500' : 'w-2 bg-white/30'}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* TRENDING MOVIES */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <SectionHeader title="Trending Movies" subtitle="Popular this week" link="/movies" />
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {movies.slice(0, 12).map((m) => (
            <MediaCard key={m._id} item={m} type="movies" />
          ))}
        </div>
      </section>

      {/* LATEST VIDEOS */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <SectionHeader title="Latest Videos" subtitle="Fresh uploads from the community" link="/videos" />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {videos.slice(0, 8).map((v) => (
            <MediaCard key={v._id} item={v} type="videos" large />
          ))}
        </div>
      </section>

      {/* POPULAR PHOTOS */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <SectionHeader title="Popular Photos" subtitle="Stunning visuals worth a thousand words" link="/photos" />
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {photos.slice(0, 10).map((p) => (
            <MediaCard key={p._id} item={p} type="photos" large />
          ))}
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <SectionHeader title="Browse Categories" link="/categories" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {['Action', 'Drama', 'Music', 'Documentary', 'Comedy', 'Sci-Fi', 'Sports', 'Lifestyle'].map((c, i) => (
            <motion.div
              key={c}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="glass rounded-2xl p-6 text-center hover:scale-105 transition cursor-pointer"
            >
              <div className="font-display text-xl font-bold">{c}</div>
              <div className="text-xs text-neutral-400 mt-1">Explore →</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <SectionHeader title="What people say" />
        <div className="grid md:grid-cols-3 gap-4">
          {[
            { n: 'Aline U.', t: 'PlayReel is hands-down the most beautiful streaming app I have used.' },
            { n: 'David K.', t: 'Uploading my own movies and watching them anywhere — game changer.' },
            { n: 'Sarah M.', t: 'Photos and music in the same place as movies. Brilliant.' },
          ].map((t) => (
            <div key={t.n} className="glass rounded-2xl p-6">
              <div className="text-yellow-400 flex gap-1 mb-2">{'★★★★★'}</div>
              <p className="text-neutral-300">"{t.t}"</p>
              <div className="mt-4 font-semibold">{t.n}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <div className="glass rounded-3xl p-10 md:p-14 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-brand-500/20 to-purple-600/20" />
          <div className="relative">
            <h2 className="font-display text-3xl md:text-5xl font-bold">Ready to share your story?</h2>
            <p className="text-neutral-300 mt-3 max-w-xl mx-auto">
              Upload your movies, videos, photos and music in seconds. From your PC or the cloud — PlayReel plays it all.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link to="/upload" className="btn-primary">Start uploading</Link>
              <Link to="/contact" className="btn-ghost">Contact us</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
