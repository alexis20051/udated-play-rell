import React, { useEffect, useState } from 'react';
import API from '../services/api.js';
import MediaCard from '../components/MediaCard.jsx';
import SectionHeader from '../components/SectionHeader.jsx';

export default function Trending() {
  const [movies, setMovies] = useState([]);
  const [videos, setVideos] = useState([]);
  useEffect(() => {
    API.get('/movies', { params: { sort: '-views', limit: 12 } }).then(({ data }) => setMovies(data));
    API.get('/videos', { params: { sort: '-views', limit: 12 } }).then(({ data }) => setVideos(data));
  }, []);
  return (
    <div className="max-w-7xl mx-auto px-4 py-10 space-y-10">
      <div>
        <SectionHeader title="Trending Movies" subtitle="Most watched right now" />
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {movies.map((m) => <MediaCard key={m._id} item={m} type="movies" />)}
        </div>
      </div>
      <div>
        <SectionHeader title="Trending Videos" subtitle="Most watched right now" />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {videos.map((v) => <MediaCard key={v._id} item={v} type="videos" large />)}
        </div>
      </div>
    </div>
  );
}
