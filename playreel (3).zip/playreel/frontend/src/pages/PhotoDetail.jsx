import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import { FiHeart, FiShare2, FiEye, FiX, FiZoomIn } from 'react-icons/fi';
import API, { mediaUrl } from '../services/api.js';

export default function PhotoDetail() {
  const { id } = useParams();
  const [item, setItem] = useState(null);
  const [zoom, setZoom] = useState(false);
  const [comments, setComments] = useState([]);
  const [name, setName] = useState('');
  const [text, setText] = useState('');

  useEffect(() => {
    API.get(`/photos/${id}`).then(({ data }) => setItem(data));
    API.get('/comments', { params: { contentType: 'photo', contentId: id } })
      .then(({ data }) => setComments(data));
  }, [id]);

  const like = async () => {
    const { data } = await API.post(`/photos/${id}/like`);
    setItem((p) => ({ ...p, likes: data.likes }));
    toast.success('Liked!');
  };

  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: item?.title, url });
      else { await navigator.clipboard.writeText(url); toast.success('Link copied!'); }
    } catch {}
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    const { data } = await API.post('/comments', {
      name: name || 'Guest', text, contentType: 'photo', contentId: id,
    });
    setComments([data, ...comments]);
    setText('');
  };

  if (!item) return <div className="max-w-5xl mx-auto px-4 py-10 text-neutral-400">Loading…</div>;

  const src = mediaUrl(item.image);

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <button
        onClick={() => setZoom(true)}
        className="group relative block w-full overflow-hidden rounded-2xl bg-black/40"
        title="Click to enlarge"
      >
        <img src={src} alt={item.title} className="w-full max-h-[70vh] object-contain" />
        <span className="absolute top-3 right-3 bg-black/60 backdrop-blur px-3 py-1.5 rounded-full text-xs flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
          <FiZoomIn /> Click to enlarge
        </span>
      </button>

      <div className="mt-6 flex flex-wrap items-start gap-4 justify-between">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-bold">{item.title}</h1>
          <div className="flex flex-wrap gap-2 mt-2 text-sm text-neutral-400">
            {item.category && <span className="px-2 py-0.5 rounded-full bg-white/10">{item.category}</span>}
            {typeof item.views === 'number' && <span className="flex items-center gap-1"><FiEye /> {item.views}</span>}
            <span className="flex items-center gap-1"><FiHeart /> {item.likes || 0}</span>
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={like} className="btn-ghost"><FiHeart /> Like</button>
          <button onClick={share} className="btn-ghost"><FiShare2 /> Share</button>
        </div>
      </div>

      {item.description && <p className="mt-4 text-neutral-300 leading-relaxed">{item.description}</p>}

      <div className="mt-10">
        <h2 className="section-title mb-3">Comments ({comments.length})</h2>
        <form onSubmit={submit} className="glass rounded-2xl p-4 mb-5 grid gap-3">
          <div className="grid md:grid-cols-[200px_1fr] gap-3">
            <input className="input" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
            <input className="input" placeholder="Add a comment…" value={text} onChange={(e) => setText(e.target.value)} />
          </div>
          <button className="btn-primary justify-self-end">Post</button>
        </form>
        <div className="space-y-3">
          {comments.map((c) => (
            <div key={c._id} className="glass rounded-2xl p-4">
              <div className="font-semibold text-sm">{c.name}</div>
              <p className="text-neutral-300 mt-1">{c.text}</p>
            </div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {zoom && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/95 grid place-items-center p-4"
            onClick={() => setZoom(false)}
          >
            <button
              className="absolute top-4 right-4 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 grid place-items-center"
              onClick={(e) => { e.stopPropagation(); setZoom(false); }}
              aria-label="Close"
            >
              <FiX className="text-2xl" />
            </button>
            <motion.img
              initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }}
              src={src} alt={item.title}
              className="max-w-full max-h-full object-contain rounded-xl cursor-zoom-out"
              onClick={(e) => { e.stopPropagation(); setZoom(false); }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
