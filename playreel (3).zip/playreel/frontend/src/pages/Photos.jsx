import React from 'react';
import MediaList from './MediaList.jsx';
export default function Photos() { return <MediaList title="Photos" endpoint="/photos" type="photos" large />; }
