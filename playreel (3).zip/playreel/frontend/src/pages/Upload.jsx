import React, { useState } from 'react';
import toast from 'react-hot-toast';
import API from '../services/api.js';

const TYPES = [
  { key: 'videos',  label: 'Video',  endpoint: '/videos',  files: ['thumbnail', 'video'] },
  { key: 'photos',  label: 'Photo',  endpoint: '/photos',  files: ['image'] },
  { key: 'music',   label: 'Music',  endpoint: '/music',   files: ['cover', 'audio'] },
];

export default function Upload() {
  const [type, setType] = useState(TYPES[0]);
  const [form, setForm] = useState({ title: '', description: '', category: 'General', artist: '', videoUrl: '', audioUrl: '', image: '' });
  const [files, setFiles] = useState({});
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => v && fd.append(k, v));
      Object.entries(files).forEach(([k, f]) => f && fd.append(k, f));
      await API.post(type.endpoint, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success(`${type.label} uploaded!`);
      setForm({ title: '', description: '', category: 'General', artist: '', videoUrl: '', audioUrl: '', image: '' });
      setFiles({});
    } catch (err) {
      toast.error(err.response?.data?.message || 'Upload failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="font-display text-4xl font-bold">Upload your content</h1>
      <p className="text-neutral-400 mt-2">From your PC or paste a URL — PlayReel plays both.</p>

      <div className="mt-6 inline-flex gap-2 glass p-1 rounded-xl">
        {TYPES.map((t) => (
          <button
            key={t.key}
            onClick={() => setType(t)}
            className={`px-4 py-2 rounded-lg text-sm font-medium ${type.key === t.key ? 'bg-brand-500 text-white' : ''}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <form onSubmit={submit} className="glass rounded-2xl p-6 mt-5 grid gap-4">
        <input className="input" placeholder="Title" required value={form.title}
               onChange={(e) => setForm({ ...form, title: e.target.value })} />
        {type.key === 'music' && (
          <input className="input" placeholder="Artist" value={form.artist}
                 onChange={(e) => setForm({ ...form, artist: e.target.value })} />
        )}
        <textarea className="input min-h-[100px]" placeholder="Description" value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <input className="input" placeholder="Category" value={form.category}
               onChange={(e) => setForm({ ...form, category: e.target.value })} />

        {type.files.map((f) => (
          <label key={f} className="block">
            <span className="text-sm text-neutral-300 capitalize">{f} file</span>
            <input type="file"
                   accept={f === 'video' ? 'video/*' : f === 'audio' ? 'audio/*' : 'image/*'}
                   onChange={(e) => setFiles({ ...files, [f]: e.target.files[0] })}
                   className="block mt-1 w-full text-sm text-neutral-400 file:mr-3 file:px-3 file:py-2 file:rounded-lg file:border-0 file:bg-brand-500 file:text-white" />
          </label>
        ))}

        <div className="text-sm text-neutral-400">Or paste an online URL instead of uploading a file:</div>
        {type.key === 'videos' && (
          <input className="input" placeholder="Video URL (https://…)" value={form.videoUrl}
                 onChange={(e) => setForm({ ...form, videoUrl: e.target.value })} />
        )}
        {type.key === 'music' && (
          <input className="input" placeholder="Audio URL (https://…)" value={form.audioUrl}
                 onChange={(e) => setForm({ ...form, audioUrl: e.target.value })} />
        )}
        {type.key === 'photos' && (
          <input className="input" placeholder="Image URL (https://…)" value={form.image}
                 onChange={(e) => setForm({ ...form, image: e.target.value })} />
        )}

        <button disabled={loading} className="btn-primary justify-center">
          {loading ? 'Uploading…' : `Upload ${type.label}`}
        </button>
      </form>
    </div>
  );
}
