import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { FiHeart, FiShare2, FiMusic, FiPlay } from 'react-icons/fi';
import API, { mediaUrl } from '../services/api.js';

export default function MusicDetail() {
  const { id } = useParams();
  const [item, setItem] = useState(null);
  const [tracks, setTracks] = useState([]);
  const [comments, setComments] = useState([]);
  const [name, setName] = useState('');
  const [text, setText] = useState('');

  useEffect(() => {
    API.get(`/music/${id}`).then(({ data }) => setItem(data));
    API.get('/music').then(({ data }) => setTracks(data));
    API.get('/comments', { params: { contentType: 'music', contentId: id } })
      .then(({ data }) => setComments(data));
  }, [id]);

  if (!item) {
    return <div className="max-w-6xl mx-auto px-4 py-10 text-neutral-400">Loading…</div>;
  }

  const cover = mediaUrl(item.cover);
  const audio = mediaUrl(item.audioUrl);

  const like = async () => {
    const { data } = await API.post(`/music/${id}/like`);
    setItem({ ...item, likes: data.likes });
    toast.success('Liked!');
  };
  const share = async () => {
    try {
      if (navigator.share) await navigator.share({ title: item.title, url: window.location.href });
      else { await navigator.clipboard.writeText(window.location.href); toast.success('Link copied!'); }
    } catch {}
  };
  const submit = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    const { data } = await API.post('/comments', {
      name: name || 'Guest', text, contentType: 'music', contentId: id,
    });
    setComments([data, ...comments]);
    setText('');
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-10 grid lg:grid-cols-[1fr_340px] gap-8">
      {/* Now playing */}
      <div>
        <div className="glass rounded-3xl p-6 md:p-8 flex flex-col md:flex-row gap-6 items-center">
          <div className="w-48 h-48 md:w-56 md:h-56 rounded-2xl overflow-hidden bg-gradient-to-br from-brand-500/40 to-purple-600/40 grid place-items-center shrink-0 shadow-2xl">
            {cover
              ? <img src={cover} alt={item.title} className="w-full h-full object-cover" />
              : <FiMusic className="text-6xl text-white/70" />}
          </div>
          <div className="flex-1 w-full">
            <p className="text-xs uppercase tracking-widest text-brand-400">Now playing</p>
            <h1 className="font-display text-3xl md:text-4xl font-bold mt-1">{item.title}</h1>
            <p className="text-neutral-400 mt-1">{item.artist || 'Unknown artist'}</p>
            <div className="flex flex-wrap gap-2 mt-3 text-xs text-neutral-300">
              {item.category && <span className="px-2 py-0.5 rounded-full bg-white/10">{item.category}</span>}
              <span className="flex items-center gap-1"><FiHeart /> {item.likes || 0}</span>
            </div>

            {audio ? (
              <audio
                src={audio}
                controls
                autoPlay
                className="w-full mt-5"
              />
            ) : (
              <p className="mt-5 text-neutral-500">No audio file attached.</p>
            )}

            <div className="flex gap-2 mt-4">
              <button onClick={like} className="btn-ghost"><FiHeart /> Like</button>
              <button onClick={share} className="btn-ghost"><FiShare2 /> Share</button>
            </div>
          </div>
        </div>

        {item.description && (
          <p className="mt-6 text-neutral-300 leading-relaxed">{item.description}</p>
        )}

        {/* Comments */}
        <div className="mt-10">
          <h2 className="section-title mb-3">Comments ({comments.length})</h2>
          <form onSubmit={submit} className="glass rounded-2xl p-4 mb-5 grid gap-3">
            <div className="grid md:grid-cols-[200px_1fr] gap-3">
              <input className="input" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
              <input className="input" placeholder="Add a comment…" value={text} onChange={(e) => setText(e.target.value)} />
            </div>
            <button className="btn-primary justify-self-end">Post</button>
          </form>
          <div className="space-y-3">
            {comments.map((c) => (
              <div key={c._id} className="glass rounded-2xl p-4">
                <div className="font-semibold text-sm">{c.name}</div>
                <p className="text-neutral-300 mt-1">{c.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Collection sidebar */}
      <aside className="glass rounded-3xl p-4 h-fit lg:sticky lg:top-24">
        <h3 className="section-title mb-3 px-2">Music library</h3>
        <div className="max-h-[70vh] overflow-y-auto pr-1 space-y-1">
          {tracks.length === 0 && <p className="text-neutral-500 px-2">No music uploaded yet.</p>}
          {tracks.map((t) => {
            const active = t._id === id;
            return (
              <Link
                key={t._id}
                to={`/music/${t._id}`}
                className={`flex items-center gap-3 p-2 rounded-xl transition ${
                  active ? 'bg-brand-500/20 ring-1 ring-brand-500/40' : 'hover:bg-white/5'
                }`}
              >
                <div className="w-12 h-12 rounded-lg overflow-hidden bg-white/10 grid place-items-center shrink-0">
                  {t.cover
                    ? <img src={mediaUrl(t.cover)} alt="" className="w-full h-full object-cover" />
                    : <FiMusic className="text-white/70" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium truncate">{t.title}</div>
                  <div className="text-xs text-neutral-400 truncate">{t.artist || 'Unknown'}</div>
                </div>
                <FiPlay className={active ? 'text-brand-400' : 'text-neutral-500'} />
              </Link>
            );
          })}
        </div>
      </aside>
    </div>
  );
}
