import React from 'react';
import DetailPage from './DetailPage.jsx';
export default function VideoDetail() { return <DetailPage endpoint="/videos" type="video" mediaKind="video" />; }
