import React from 'react';
import { Link } from 'react-router-dom';
export default function NotFound() {
  return (
    <div className="min-h-[60vh] grid place-items-center text-center px-4">
      <div>
        <div className="font-display text-7xl font-bold bg-gradient-to-r from-brand-500 to-purple-500 bg-clip-text text-transparent">404</div>
        <p className="text-neutral-400 mt-2">This page wandered off the reel.</p>
        <Link to="/" className="btn-primary mt-5">Go home</Link>
      </div>
    </div>
  );
}
