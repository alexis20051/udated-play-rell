import React from 'react';
import MediaList from './MediaList.jsx';
export default function Music() { return <MediaList title="Music" endpoint="/music" type="music" />; }
