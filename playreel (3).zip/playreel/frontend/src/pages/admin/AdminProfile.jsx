import React, { useState } from 'react';
import toast from 'react-hot-toast';
import { useDispatch, useSelector } from 'react-redux';
import API, { mediaUrl } from '../../services/api.js';
import { setUser } from '../../redux/slices/authSlice.js';

export default function AdminProfile() {
  const dispatch = useDispatch();
  const user = useSelector((s) => s.auth.user);
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [photo, setPhoto] = useState(null);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const saveProfile = async (e) => {
    e.preventDefault();
    const fd = new FormData();
    fd.append('name', name);
    fd.append('phone', phone);
    if (photo) fd.append('photo', photo);
    const { data } = await API.put('/auth/admin/profile', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
    dispatch(setUser({ ...user, name: data.admin.name, photo: data.admin.photo }));
    toast.success('Profile updated');
  };

  const changePw = async (e) => {
    e.preventDefault();
    try {
      await API.put('/auth/admin/password', { oldPassword, newPassword });
      toast.success('Password changed');
      setOldPassword(''); setNewPassword('');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed');
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-5">
      <form onSubmit={saveProfile} className="glass rounded-2xl p-5 space-y-3">
        <h2 className="section-title">Profile</h2>
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-full overflow-hidden bg-white/10 grid place-items-center text-2xl">
            {user?.photo ? <img src={mediaUrl(user.photo)} alt="" className="w-full h-full object-cover" /> : '👤'}
          </div>
          <input type="file" accept="image/*" onChange={(e) => setPhoto(e.target.files[0])}
                 className="text-sm file:mr-3 file:px-3 file:py-2 file:rounded-lg file:border-0 file:bg-brand-500 file:text-white" />
        </div>
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" />
        <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone" />
        <input className="input" value={user?.email || ''} disabled />
        <button className="btn-primary justify-self-end">Save</button>
      </form>

      <form onSubmit={changePw} className="glass rounded-2xl p-5 space-y-3">
        <h2 className="section-title">Change password</h2>
        <input className="input" type="password" placeholder="Current password" required
               value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} />
        <input className="input" type="password" placeholder="New password" required minLength={6}
               value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
        <button className="btn-primary justify-self-end">Update password</button>
      </form>
    </div>
  );
}
