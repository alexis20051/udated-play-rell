import React from 'react';
import ManageMedia from './ManageMedia.jsx';
export default function ManageVideos() {
  return (
    <ManageMedia
      title="Videos"
      endpoint="/videos"
      extraFields={['tags']}
      fileFields={[
        { name: 'thumbnail', label: 'Thumbnail', accept: 'image/*' },
        { name: 'video', label: 'Video file', accept: 'video/*' },
      ]}
    />
  );
}
