import React from 'react';
import ManageMedia from './ManageMedia.jsx';
export default function ManagePhotos() {
  return (
    <ManageMedia
      title="Photos"
      endpoint="/photos"
      fileFields={[{ name: 'image', label: 'Image', accept: 'image/*' }]}
    />
  );
}
