import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { adminLogin } from '../../redux/slices/authSlice.js';

export default function AdminLogin() {
  const [email, setEmail] = useState('admin@playreel.com');
  const [password, setPassword] = useState('Admin@123');
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { loading } = useSelector((s) => s.auth);

  const submit = async (e) => {
    e.preventDefault();
    const res = await dispatch(adminLogin({ email, password }));
    if (res.meta.requestStatus === 'fulfilled') {
      toast.success('Welcome back!');
      navigate('/admin');
    } else {
      toast.error(res.payload || 'Login failed');
    }
  };

  return (
    <div className="min-h-screen grid place-items-center px-4 bg-hero-gradient">
      <motion.form
        onSubmit={submit}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-3xl p-8 w-full max-w-md"
      >
        <div className="font-display text-3xl font-bold mb-1">
          <span className="bg-gradient-to-r from-brand-500 to-purple-500 bg-clip-text text-transparent">Play</span>Reel
        </div>
        <p className="text-neutral-400 text-sm">Admin sign in</p>
        <div className="mt-6 space-y-3">
          <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
          <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" required />
        </div>
        <button disabled={loading} className="btn-primary w-full justify-center mt-6">
          {loading ? 'Signing in…' : 'Sign in'}
        </button>
        <div className="flex justify-between text-sm mt-4 text-neutral-400">
          <Link to="/admin/forgot" className="hover:text-brand-400">Forgot password?</Link>
          <Link to="/" className="hover:text-brand-400">← Back to site</Link>
        </div>
      </motion.form>
    </div>
  );
}
