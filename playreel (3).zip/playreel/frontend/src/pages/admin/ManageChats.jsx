import React, { useEffect, useRef, useState } from 'react';
import API from '../../services/api.js';
import socket from '../../services/socket.js';

export default function ManageChats() {
  const [sessions, setSessions] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const endRef = useRef(null);

  const loadSessions = () => API.get('/chats').then(({ data }) => setSessions(data));

  useEffect(() => {
    socket.emit('admin:join');
    loadSessions();
    const onMsg = (m) => {
      loadSessions();
      if (m.sessionId === activeId) setMessages((prev) => [...prev, m]);
    };
    socket.on('chat:message', onMsg);
    return () => socket.off('chat:message', onMsg);
  }, [activeId]);

  useEffect(() => {
    if (!activeId) return;
    API.get(`/chats/${activeId}`).then(({ data }) => setMessages(data));
    API.put(`/chats/${activeId}/read`).catch(() => {});
  }, [activeId]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const send = async (e) => {
    e.preventDefault();
    if (!text.trim() || !activeId) return;
    socket.emit('chat:message', { sessionId: activeId, sender: 'admin', name: 'Admin', text: text.trim() });
    setText('');
  };

  return (
    <div className="grid lg:grid-cols-[280px_1fr] gap-4 h-[calc(100vh-180px)]">
      <div className="glass rounded-2xl overflow-y-auto">
        <div className="p-3 border-b border-white/10 font-semibold">Conversations</div>
        {sessions.map((s) => (
          <button
            key={s._id}
            onClick={() => setActiveId(s._id)}
            className={`w-full text-left p-3 border-b border-white/5 hover:bg-white/5 ${activeId === s._id ? 'bg-white/5' : ''}`}
          >
            <div className="flex justify-between items-center">
              <div className="font-medium text-sm">{s.name}</div>
              {s.unread > 0 && <span className="text-[10px] bg-brand-500 text-white rounded-full px-1.5">{s.unread}</span>}
            </div>
            <div className="text-xs text-neutral-400 line-clamp-1">{s.lastMessage}</div>
          </button>
        ))}
        {!sessions.length && <p className="p-4 text-sm text-neutral-400">No chats yet.</p>}
      </div>

      <div className="glass rounded-2xl flex flex-col">
        {activeId ? (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {messages.map((m) => (
                <div key={m._id} className={`max-w-[70%] px-3 py-2 rounded-2xl text-sm ${
                  m.sender === 'admin' ? 'ml-auto bg-gradient-to-br from-brand-500 to-purple-600 text-white' : 'bg-white/10'
                }`}>
                  <div className="text-[10px] opacity-70 mb-0.5">{m.name}</div>
                  {m.text}
                </div>
              ))}
              <div ref={endRef} />
            </div>
            <form onSubmit={send} className="p-3 border-t border-white/10 flex gap-2">
              <input className="input flex-1" placeholder="Reply…" value={text} onChange={(e) => setText(e.target.value)} />
              <button className="btn-primary">Send</button>
            </form>
          </>
        ) : (
          <div className="grid place-items-center flex-1 text-neutral-400">Select a conversation</div>
        )}
      </div>
    </div>
  );
}
