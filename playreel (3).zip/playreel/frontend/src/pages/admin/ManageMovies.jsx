import React from 'react';
import ManageMedia from './ManageMedia.jsx';
export default function ManageMovies() {
  return (
    <ManageMedia
      title="Movies"
      endpoint="/movies"
      extraFields={['genre']}
      fileFields={[
        { name: 'thumbnail', label: 'Thumbnail', accept: 'image/*' },
        { name: 'banner', label: 'Banner', accept: 'image/*' },
        { name: 'video', label: 'Movie file', accept: 'video/*' },
        { name: 'trailer', label: 'Trailer', accept: 'video/*' },
      ]}
    />
  );
}
