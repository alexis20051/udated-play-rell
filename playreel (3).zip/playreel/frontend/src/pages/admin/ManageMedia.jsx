import React, { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { FiTrash2, FiPlus } from 'react-icons/fi';
import API, { mediaUrl } from '../../services/api.js';

/**
 * Generic admin media manager — list + upload + delete.
 * fields: array of { name, type } — file fields rendered as <input type="file" />
 */
export default function ManageMedia({ title, endpoint, fileFields, extraFields = [], type }) {
  const [items, setItems] = useState([]);
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({});
  const [files, setFiles] = useState({});
  const [loading, setLoading] = useState(false);

  const load = () => API.get(endpoint).then(({ data }) => setItems(data));
  useEffect(() => { load(); }, []); // eslint-disable-line

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => v && fd.append(k, v));
      Object.entries(files).forEach(([k, f]) => f && fd.append(k, f));
      await API.post(endpoint, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success('Uploaded!');
      setForm({}); setFiles({}); setShow(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed');
    } finally { setLoading(false); }
  };

  const del = async (id) => {
    if (!confirm('Delete this item?')) return;
    await API.delete(`${endpoint}/${id}`);
    toast.success('Deleted');
    load();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h2 className="section-title">Manage {title}</h2>
        <button onClick={() => setShow((v) => !v)} className="btn-primary"><FiPlus /> New</button>
      </div>

      {show && (
        <form onSubmit={submit} className="glass rounded-2xl p-5 mb-5 grid md:grid-cols-2 gap-3">
          <input className="input" placeholder="Title" required value={form.title || ''}
                 onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <input className="input" placeholder="Category" value={form.category || ''}
                 onChange={(e) => setForm({ ...form, category: e.target.value })} />
          {extraFields.map((f) => (
            <input key={f} className="input" placeholder={f} value={form[f] || ''}
                   onChange={(e) => setForm({ ...form, [f]: e.target.value })} />
          ))}
          <textarea className="input md:col-span-2 min-h-[80px]" placeholder="Description"
                    value={form.description || ''}
                    onChange={(e) => setForm({ ...form, description: e.target.value })} />
          {fileFields.map((f) => (
            <label key={f.name} className="md:col-span-1">
              <span className="text-sm text-neutral-300">{f.label}</span>
              <input type="file" accept={f.accept}
                     onChange={(e) => setFiles({ ...files, [f.name]: e.target.files[0] })}
                     className="block mt-1 w-full text-sm file:mr-3 file:px-3 file:py-2 file:rounded-lg file:border-0 file:bg-brand-500 file:text-white" />
            </label>
          ))}
          <button disabled={loading} className="btn-primary md:col-span-2 justify-center">
            {loading ? 'Uploading…' : 'Save'}
          </button>
        </form>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {items.map((i) => (
          <div key={i._id} className="glass rounded-2xl overflow-hidden">
            <div className="aspect-video bg-black/40">
              {(i.thumbnail || i.image || i.cover || i.banner) && (
                <img src={mediaUrl(i.thumbnail || i.image || i.cover || i.banner)} alt="" className="w-full h-full object-cover" />
              )}
            </div>
            <div className="p-3">
              <div className="font-semibold text-sm line-clamp-1">{i.title}</div>
              <div className="text-xs text-neutral-400">{i.category}</div>
              <div className="flex justify-end mt-2">
                <button onClick={() => del(i._id)} className="text-red-400 hover:text-red-300 text-sm flex items-center gap-1">
                  <FiTrash2 /> Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
