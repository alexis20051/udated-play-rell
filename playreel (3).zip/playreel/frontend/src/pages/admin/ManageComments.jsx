import React, { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import API from '../../services/api.js';

export default function ManageComments() {
  const [items, setItems] = useState([]);
  const load = () => API.get('/comments').then(({ data }) => setItems(data));
  useEffect(() => { load(); }, []);
  const del = async (id) => {
    await API.delete(`/comments/${id}`); toast.success('Deleted'); load();
  };
  return (
    <div className="glass rounded-2xl p-5">
      <h2 className="section-title mb-4">Comments</h2>
      <div className="space-y-3">
        {items.map((c) => (
          <div key={c._id} className="p-4 rounded-xl bg-white/[0.03] border border-white/5">
            <div className="flex justify-between text-sm">
              <div className="font-semibold">{c.name} <span className="text-neutral-400 font-normal">on {c.contentType}</span></div>
              <div className="text-xs text-neutral-400">{new Date(c.createdAt).toLocaleString()}</div>
            </div>
            <p className="mt-1 text-neutral-200">{c.text}</p>
            <button onClick={() => del(c._id)} className="text-red-400 text-xs mt-2">Delete</button>
          </div>
        ))}
        {!items.length && <p className="text-neutral-400">No comments yet.</p>}
      </div>
    </div>
  );
}
