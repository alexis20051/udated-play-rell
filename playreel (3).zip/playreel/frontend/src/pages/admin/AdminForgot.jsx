import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import API from '../../services/api.js';

export default function AdminForgot() {
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const navigate = useNavigate();
  const submit = async (e) => {
    e.preventDefault();
    try {
      await API.post('/auth/admin/forgot', { email, newPassword });
      toast.success('Password reset. Please sign in.');
      navigate('/admin/login');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed');
    }
  };
  return (
    <div className="min-h-screen grid place-items-center px-4 bg-hero-gradient">
      <form onSubmit={submit} className="glass rounded-3xl p-8 w-full max-w-md">
        <div className="font-display text-2xl font-bold">Reset admin password</div>
        <div className="mt-5 space-y-3">
          <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Admin email" required />
          <input className="input" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="New password" required />
        </div>
        <button className="btn-primary w-full justify-center mt-5">Reset password</button>
        <Link to="/admin/login" className="block text-center text-sm mt-4 text-neutral-400 hover:text-brand-400">← Back to sign in</Link>
      </form>
    </div>
  );
}
