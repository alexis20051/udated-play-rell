import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid, Legend,
} from 'recharts';
import { FiFilm, FiVideo, FiImage, FiMusic, FiUsers, FiMail, FiMessageSquare } from 'react-icons/fi';
import API from '../../services/api.js';

const cards = [
  { key: 'movies', icon: FiFilm, label: 'Movies', color: 'from-brand-500 to-pink-500' },
  { key: 'videos', icon: FiVideo, label: 'Videos', color: 'from-purple-500 to-indigo-500' },
  { key: 'photos', icon: FiImage, label: 'Photos', color: 'from-cyan-500 to-blue-500' },
  { key: 'music', icon: FiMusic, label: 'Music', color: 'from-emerald-500 to-teal-500' },
  { key: 'users', icon: FiUsers, label: 'Users', color: 'from-orange-500 to-red-500' },
  { key: 'contacts', icon: FiMail, label: 'Contacts', color: 'from-yellow-500 to-amber-500' },
  { key: 'feedbacks', icon: FiMessageSquare, label: 'Feedback', color: 'from-rose-500 to-pink-500' },
];

export default function Dashboard() {
  const [data, setData] = useState(null);
  useEffect(() => { API.get('/dashboard/stats').then(({ data }) => setData(data)); }, []);
  if (!data) return <p className="text-neutral-400">Loading dashboard…</p>;
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {cards.map(({ key, icon: Icon, label, color }, i) => (
          <motion.div
            key={key}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.03 }}
            className="glass rounded-2xl p-4"
          >
            <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${color} grid place-items-center mb-2`}>
              <Icon className="text-white" />
            </div>
            <div className="text-2xl font-bold">{data.counts[key] ?? 0}</div>
            <div className="text-xs text-neutral-400">{label}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="glass rounded-2xl p-5">
          <h3 className="font-display font-bold mb-3">Uploads this period</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={data.chart}>
              <CartesianGrid stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="month" stroke="#777" />
              <YAxis stroke="#777" />
              <Tooltip contentStyle={{ background: '#111', border: '1px solid #333', borderRadius: 10 }} />
              <Legend />
              <Line type="monotone" dataKey="movies" stroke="#ff2e57" strokeWidth={2} />
              <Line type="monotone" dataKey="videos" stroke="#7c3aed" strokeWidth={2} />
              <Line type="monotone" dataKey="photos" stroke="#06b6d4" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="glass rounded-2xl p-5">
          <h3 className="font-display font-bold mb-3">Top movies by views</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={data.topMovies.map((m) => ({ name: m.title.slice(0, 14), views: m.views }))}>
              <CartesianGrid stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="name" stroke="#777" />
              <YAxis stroke="#777" />
              <Tooltip contentStyle={{ background: '#111', border: '1px solid #333', borderRadius: 10 }} />
              <Bar dataKey="views" fill="url(#g)" radius={[6, 6, 0, 0]} />
              <defs>
                <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="#ff2e57" />
                  <stop offset="100%" stopColor="#7c3aed" />
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="glass rounded-2xl p-5">
        <h3 className="font-display font-bold mb-3">Recent movies</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-left text-neutral-400 border-b border-white/10">
              <tr><th className="py-2">Title</th><th>Category</th><th>Views</th><th>Likes</th><th>Created</th></tr>
            </thead>
            <tbody>
              {data.recentMovies.map((m) => (
                <tr key={m._id} className="border-b border-white/5">
                  <td className="py-2 font-medium">{m.title}</td>
                  <td>{m.category}</td>
                  <td>{m.views}</td>
                  <td>{m.likes}</td>
                  <td className="text-neutral-400">{new Date(m.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
