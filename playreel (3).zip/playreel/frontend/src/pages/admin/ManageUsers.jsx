import React, { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import API from '../../services/api.js';

export default function ManageUsers() {
  const [users, setUsers] = useState([]);
  const load = () => API.get('/users').then(({ data }) => setUsers(data));
  useEffect(() => { load(); }, []);
  const block = async (id) => { await API.put(`/users/${id}/block`); toast.success('Updated'); load(); };
  const del = async (id) => {
    if (!confirm('Delete user?')) return;
    await API.delete(`/users/${id}`); toast.success('Deleted'); load();
  };
  return (
    <div className="glass rounded-2xl p-5">
      <h2 className="section-title mb-4">Users</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-neutral-400 border-b border-white/10">
            <tr><th className="py-2">Name</th><th>Email</th><th>Status</th><th>Joined</th><th /></tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u._id} className="border-b border-white/5">
                <td className="py-2 font-medium">{u.name}</td>
                <td>{u.email}</td>
                <td>{u.blocked ? <span className="text-red-400">Blocked</span> : <span className="text-emerald-400">Active</span>}</td>
                <td className="text-neutral-400">{new Date(u.createdAt).toLocaleDateString()}</td>
                <td className="text-right space-x-2">
                  <button onClick={() => block(u._id)} className="text-yellow-400">{u.blocked ? 'Unblock' : 'Block'}</button>
                  <button onClick={() => del(u._id)} className="text-red-400">Delete</button>
                </td>
              </tr>
            ))}
            {!users.length && <tr><td className="py-4 text-neutral-400" colSpan={5}>No users yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
