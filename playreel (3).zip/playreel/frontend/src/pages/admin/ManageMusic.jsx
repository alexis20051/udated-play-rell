import React from 'react';
import ManageMedia from './ManageMedia.jsx';
export default function ManageMusic() {
  return (
    <ManageMedia
      title="Music"
      endpoint="/music"
      extraFields={['artist']}
      fileFields={[
        { name: 'cover', label: 'Cover', accept: 'image/*' },
        { name: 'audio', label: 'Audio file', accept: 'audio/*' },
      ]}
    />
  );
}
