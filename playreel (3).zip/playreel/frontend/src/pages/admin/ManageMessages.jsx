import React, { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import API from '../../services/api.js';

export default function ManageMessages() {
  const [tab, setTab] = useState('contact');
  const [items, setItems] = useState([]);
  const load = () => API.get(`/${tab}`).then(({ data }) => setItems(data));
  useEffect(() => { load(); }, [tab]); // eslint-disable-line
  const del = async (id) => {
    await API.delete(`/${tab}/${id}`); toast.success('Deleted'); load();
  };
  const read = async (id) => { await API.put(`/${tab}/${id}/read`); load(); };
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="section-title">Messages</h2>
        <div className="inline-flex gap-1 glass p-1 rounded-xl">
          {['contact', 'feedback'].map((t) => (
            <button key={t} onClick={() => setTab(t)}
                    className={`px-4 py-1.5 rounded-lg text-sm capitalize ${tab === t ? 'bg-brand-500 text-white' : ''}`}>
              {t}
            </button>
          ))}
        </div>
      </div>
      <div className="space-y-3">
        {items.map((m) => (
          <div key={m._id} className={`p-4 rounded-xl border ${m.read ? 'border-white/5 bg-white/[0.02]' : 'border-brand-500/30 bg-brand-500/5'}`}>
            <div className="flex justify-between text-sm">
              <div className="font-semibold">{m.name} <span className="text-neutral-400 font-normal">— {m.email}</span></div>
              <div className="text-xs text-neutral-400">{new Date(m.createdAt).toLocaleString()}</div>
            </div>
            {m.subject && <div className="text-sm text-neutral-300 mt-1">Subject: {m.subject}</div>}
            <p className="mt-2 text-neutral-200">{m.message}</p>
            <div className="flex gap-3 text-xs mt-2">
              {!m.read && <button onClick={() => read(m._id)} className="text-emerald-400">Mark read</button>}
              <button onClick={() => del(m._id)} className="text-red-400">Delete</button>
            </div>
          </div>
        ))}
        {!items.length && <p className="text-neutral-400">No messages.</p>}
      </div>
    </div>
  );
}
