import React, { useEffect, useState } from 'react';
import API from '../services/api.js';
import MediaCard from '../components/MediaCard.jsx';
import SectionHeader from '../components/SectionHeader.jsx';

export default function MediaList({ title, endpoint, type, large = false }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');

  useEffect(() => {
    setLoading(true);
    API.get(endpoint, { params: q ? { q } : {} })
      .then(({ data }) => setItems(data))
      .finally(() => setLoading(false));
  }, [endpoint, q]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <SectionHeader title={title} subtitle={`Browse all ${title.toLowerCase()}`} />
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder={`Search ${title.toLowerCase()}…`}
        className="input mb-6 max-w-md"
      />
      {loading ? (
        <p className="text-neutral-400">Loading…</p>
      ) : items.length === 0 ? (
        <p className="text-neutral-400">No items yet.</p>
      ) : (
        <div className={`grid gap-4 ${large ? 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4' : 'grid-cols-2 md:grid-cols-4 lg:grid-cols-6'}`}>
          {items.map((item) => (
            <MediaCard key={item._id} item={item} type={type} large={large} />
          ))}
        </div>
      )}
    </div>
  );
}
