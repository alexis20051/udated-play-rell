import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import API from '../../services/api.js';

const fetcher = (path) => async (params = {}) => (await API.get(path, { params })).data;

export const fetchMovies = createAsyncThunk('media/movies', fetcher('/movies'));
export const fetchVideos = createAsyncThunk('media/videos', fetcher('/videos'));
export const fetchPhotos = createAsyncThunk('media/photos', fetcher('/photos'));
export const fetchMusic = createAsyncThunk('media/music', fetcher('/music'));

const slice = createSlice({
  name: 'media',
  initialState: { movies: [], videos: [], photos: [], music: [], loading: false },
  reducers: {},
  extraReducers: (b) => {
    [
      [fetchMovies, 'movies'],
      [fetchVideos, 'videos'],
      [fetchPhotos, 'photos'],
      [fetchMusic, 'music'],
    ].forEach(([thunk, key]) => {
      b.addCase(thunk.pending, (s) => { s.loading = true; });
      b.addCase(thunk.fulfilled, (s, a) => { s.loading = false; s[key] = a.payload; });
      b.addCase(thunk.rejected, (s) => { s.loading = false; });
    });
  },
});

export default slice.reducer;
