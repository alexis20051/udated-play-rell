import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import API from '../../services/api.js';

const tokenKey = 'playreel_token';
const userKey = 'playreel_user';

const initial = {
  user: JSON.parse(localStorage.getItem(userKey) || 'null'),
  token: localStorage.getItem(tokenKey) || null,
  loading: false,
  error: null,
};

export const adminLogin = createAsyncThunk('auth/adminLogin', async (creds, { rejectWithValue }) => {
  try {
    const { data } = await API.post('/auth/admin/login', creds);
    localStorage.setItem(tokenKey, data.token);
    localStorage.setItem(userKey, JSON.stringify(data));
    return data;
  } catch (e) {
    return rejectWithValue(e.response?.data?.message || e.message);
  }
});

const slice = createSlice({
  name: 'auth',
  initialState: initial,
  reducers: {
    logout(state) {
      state.user = null;
      state.token = null;
      localStorage.removeItem(tokenKey);
      localStorage.removeItem(userKey);
    },
    setUser(state, action) {
      state.user = action.payload;
      localStorage.setItem(userKey, JSON.stringify(action.payload));
    },
  },
  extraReducers: (b) => {
    b.addCase(adminLogin.pending, (s) => { s.loading = true; s.error = null; });
    b.addCase(adminLogin.fulfilled, (s, a) => {
      s.loading = false;
      s.user = a.payload;
      s.token = a.payload.token;
    });
    b.addCase(adminLogin.rejected, (s, a) => { s.loading = false; s.error = a.payload; });
  },
});

export const { logout, setUser } = slice.actions;
export default slice.reducer;
