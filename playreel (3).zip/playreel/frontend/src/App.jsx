import React from 'react';
import { Routes, Route } from 'react-router-dom';
import MainLayout from './layouts/MainLayout.jsx';
import AdminLayout from './layouts/AdminLayout.jsx';
import Home from './pages/Home.jsx';
import Movies from './pages/Movies.jsx';
import MovieDetail from './pages/MovieDetail.jsx';
import Videos from './pages/Videos.jsx';
import VideoDetail from './pages/VideoDetail.jsx';
import PhotoDetail from './pages/PhotoDetail.jsx';
import MusicDetail from './pages/MusicDetail.jsx';
import Photos from './pages/Photos.jsx';
import Music from './pages/Music.jsx';
import Trending from './pages/Trending.jsx';
import Categories from './pages/Categories.jsx';
import Search from './pages/Search.jsx';
import Contact from './pages/Contact.jsx';
import Upload from './pages/Upload.jsx';
import NotFound from './pages/NotFound.jsx';
import AdminLogin from './pages/admin/AdminLogin.jsx';
import AdminForgot from './pages/admin/AdminForgot.jsx';
import Dashboard from './pages/admin/Dashboard.jsx';
import ManageMovies from './pages/admin/ManageMovies.jsx';
import ManageVideos from './pages/admin/ManageVideos.jsx';
import ManagePhotos from './pages/admin/ManagePhotos.jsx';
import ManageMusic from './pages/admin/ManageMusic.jsx';
import ManageUsers from './pages/admin/ManageUsers.jsx';
import ManageMessages from './pages/admin/ManageMessages.jsx';
import ManageChats from './pages/admin/ManageChats.jsx';
import ManageComments from './pages/admin/ManageComments.jsx';
import AdminProfile from './pages/admin/AdminProfile.jsx';
import ProtectedAdmin from './components/ProtectedAdmin.jsx';
import ChatWidget from './components/ChatWidget.jsx';

export default function App() {
  return (
    <>
      <Routes>
        <Route element={<MainLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/movies" element={<Movies />} />
          <Route path="/movies/:id" element={<MovieDetail />} />
          <Route path="/videos" element={<Videos />} />
          <Route path="/videos/:id" element={<VideoDetail />} />
          <Route path="/photos" element={<Photos />} />
          <Route path="/photos/:id" element={<PhotoDetail />} />
          <Route path="/music" element={<Music />} />
          <Route path="/music/:id" element={<MusicDetail />} />
          <Route path="/trending" element={<Trending />} />
          <Route path="/categories" element={<Categories />} />
          <Route path="/search" element={<Search />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/upload" element={<Upload />} />
        </Route>

        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/admin/forgot" element={<AdminForgot />} />

        <Route
          path="/admin"
          element={
            <ProtectedAdmin>
              <AdminLayout />
            </ProtectedAdmin>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="movies" element={<ManageMovies />} />
          <Route path="videos" element={<ManageVideos />} />
          <Route path="photos" element={<ManagePhotos />} />
          <Route path="music" element={<ManageMusic />} />
          <Route path="users" element={<ManageUsers />} />
          <Route path="messages" element={<ManageMessages />} />
          <Route path="chats" element={<ManageChats />} />
          <Route path="comments" element={<ManageComments />} />
          <Route path="profile" element={<AdminProfile />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
      <ChatWidget />
    </>
  );
}
