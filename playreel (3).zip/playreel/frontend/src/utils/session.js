export const getSessionId = () => {
  let id = localStorage.getItem('pr_chat_session');
  if (!id) {
    id = 'sess_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem('pr_chat_session', id);
  }
  return id;
};

export const getGuestName = () => localStorage.getItem('pr_guest_name') || 'Guest';
export const setGuestName = (n) => localStorage.setItem('pr_guest_name', n);
