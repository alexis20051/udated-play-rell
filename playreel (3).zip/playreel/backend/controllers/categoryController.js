const Category = require('../models/Category');

exports.list = async (req, res) => {
  const items = await Category.find().sort('name');
  res.json(items);
};

exports.create = async (req, res) => {
  const { name, description, icon } = req.body;
  if (!name) return res.status(400).json({ message: 'Name required' });
  const c = await Category.create({ name, description, icon });
  res.status(201).json(c);
};

exports.remove = async (req, res) => {
  await Category.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
};
