const Comment = require('../models/Comment');

exports.list = async (req, res) => {
  const { contentType, contentId } = req.query;
  const filter = {};
  if (contentType) filter.contentType = contentType;
  if (contentId) filter.contentId = contentId;
  const items = await Comment.find(filter).sort('-createdAt').limit(200);
  res.json(items);
};

exports.create = async (req, res) => {
  const { name, text, contentType, contentId } = req.body;
  if (!text || !contentType || !contentId)
    return res.status(400).json({ message: 'Missing fields' });
  const c = await Comment.create({ name: name || 'Guest', text, contentType, contentId });
  res.status(201).json(c);
};

exports.remove = async (req, res) => {
  await Comment.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
};
