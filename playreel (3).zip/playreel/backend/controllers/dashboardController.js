const User = require('../models/User');
const Movie = require('../models/Movie');
const Video = require('../models/Video');
const Photo = require('../models/Photo');
const Music = require('../models/Music');
const Message = require('../models/Message');
const Comment = require('../models/Comment');

exports.stats = async (req, res) => {
  const [users, movies, videos, photos, music, contacts, feedbacks, comments] = await Promise.all([
    User.countDocuments(),
    Movie.countDocuments(),
    Video.countDocuments(),
    Photo.countDocuments(),
    Music.countDocuments(),
    Message.countDocuments({ type: 'contact' }),
    Message.countDocuments({ type: 'feedback' }),
    Comment.countDocuments(),
  ]);

  const recentMovies = await Movie.find().sort('-createdAt').limit(5);
  const topMovies = await Movie.find().sort('-views').limit(5);

  // simple per-month chart for last 6 months
  const chart = [];
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
    const [m, v, p] = await Promise.all([
      Movie.countDocuments({ createdAt: { $gte: start, $lt: end } }),
      Video.countDocuments({ createdAt: { $gte: start, $lt: end } }),
      Photo.countDocuments({ createdAt: { $gte: start, $lt: end } }),
    ]);
    chart.push({
      month: start.toLocaleString('en-US', { month: 'short' }),
      movies: m,
      videos: v,
      photos: p,
    });
  }

  res.json({
    counts: { users, movies, videos, photos, music, contacts, feedbacks, comments },
    recentMovies,
    topMovies,
    chart,
  });
};
