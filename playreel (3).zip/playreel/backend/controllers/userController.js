const User = require('../models/User');

exports.list = async (req, res) => {
  const users = await User.find().select('-password').sort('-createdAt');
  res.json(users);
};

exports.block = async (req, res) => {
  const u = await User.findById(req.params.id);
  if (!u) return res.status(404).json({ message: 'Not found' });
  u.blocked = !u.blocked;
  await u.save();
  res.json(u);
};

exports.remove = async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
};
