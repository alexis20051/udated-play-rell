const Notification = require('../models/Notification');

exports.list = async (req, res) => {
  const items = await Notification.find().sort('-createdAt').limit(100);
  res.json(items);
};

exports.markRead = async (req, res) => {
  await Notification.findByIdAndUpdate(req.params.id, { read: true });
  res.json({ message: 'ok' });
};

exports.markAllRead = async (req, res) => {
  await Notification.updateMany({ read: false }, { read: true });
  res.json({ message: 'ok' });
};
