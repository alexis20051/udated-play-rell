const Chat = require('../models/Chat');

exports.listSessions = async (req, res) => {
  const sessions = await Chat.aggregate([
    { $sort: { createdAt: -1 } },
    {
      $group: {
        _id: '$sessionId',
        name: { $first: '$name' },
        lastMessage: { $first: '$text' },
        lastAt: { $first: '$createdAt' },
        unread: { $sum: { $cond: [{ $and: [{ $eq: ['$read', false] }, { $eq: ['$sender', 'user'] }] }, 1, 0] } },
      },
    },
    { $sort: { lastAt: -1 } },
  ]);
  res.json(sessions);
};

exports.getMessages = async (req, res) => {
  const messages = await Chat.find({ sessionId: req.params.sessionId }).sort('createdAt');
  res.json(messages);
};

exports.sendMessage = async (req, res) => {
  const { sessionId, sender, name, text } = req.body;
  const msg = await Chat.create({ sessionId, sender: sender || 'admin', name: name || 'Admin', text });
  const io = req.app.get('io');
  if (io) {
    io.to(sessionId).emit('chat:message', msg);
    io.to('admins').emit('chat:message', msg);
  }
  res.status(201).json(msg);
};

exports.markRead = async (req, res) => {
  await Chat.updateMany({ sessionId: req.params.sessionId, read: false }, { read: true });
  res.json({ message: 'Marked read' });
};
