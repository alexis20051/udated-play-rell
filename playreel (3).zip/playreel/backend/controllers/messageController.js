const Message = require('../models/Message');

exports.create = (type) => async (req, res) => {
  const { name, email, phone, subject, message } = req.body;
  if (!name || !email || !message)
    return res.status(400).json({ message: 'Missing required fields' });
  const m = await Message.create({ name, email, phone, subject, message, type });
  const io = req.app.get('io');
  if (io) io.emit('notification', { title: `New ${type} message`, body: name });
  res.status(201).json(m);
};

exports.list = (type) => async (req, res) => {
  const items = await Message.find({ type }).sort('-createdAt');
  res.json(items);
};

exports.markRead = async (req, res) => {
  const m = await Message.findByIdAndUpdate(req.params.id, { read: true }, { new: true });
  res.json(m);
};

exports.remove = async (req, res) => {
  await Message.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
};
