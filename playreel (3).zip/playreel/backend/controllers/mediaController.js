const { resolveFileUrl } = require('../services/fileService');
const Notification = require('../models/Notification');

/**
 * Build a CRUD controller for a media model.
 * fields: { videoField?, thumbField?, bannerField?, imageField?, audioField?, coverField? }
 */
function buildMediaController(Model, label, fields = {}) {
  return {
    list: async (req, res) => {
      const { q, category, trending, featured, limit = 50, sort = '-createdAt' } = req.query;
      const filter = {};
      if (q) filter.title = { $regex: q, $options: 'i' };
      if (category) filter.category = category;
      if (trending) filter.trending = true;
      if (featured) filter.featured = true;
      const items = await Model.find(filter).sort(sort).limit(Number(limit));
      res.json(items);
    },

    getOne: async (req, res) => {
      const item = await Model.findById(req.params.id);
      if (!item) return res.status(404).json({ message: 'Not found' });
      if (typeof item.views === 'number') {
        item.views += 1;
        await item.save();
      }
      res.json(item);
    },

    create: async (req, res) => {
      const data = { ...req.body };
      const files = req.files || {};

      for (const [key, info] of Object.entries(fields)) {
        const f = files[info.field]?.[0];
        if (f) data[key] = await resolveFileUrl(f, `playreel/${label}`);
        else if (req.body[key]) data[key] = req.body[key]; // accept direct URL
      }

      // tags as comma-separated string fallback
      if (typeof data.tags === 'string') data.tags = data.tags.split(',').map((t) => t.trim()).filter(Boolean);

      const item = await Model.create(data);
      await Notification.create({
        title: `New ${label} uploaded`,
        body: item.title,
        type: 'upload',
      });
      const io = req.app.get('io');
      if (io) io.emit('notification', { title: `New ${label}`, body: item.title });
      res.status(201).json(item);
    },

    update: async (req, res) => {
      const item = await Model.findById(req.params.id);
      if (!item) return res.status(404).json({ message: 'Not found' });
      const files = req.files || {};
      Object.assign(item, req.body);
      for (const [key, info] of Object.entries(fields)) {
        const f = files[info.field]?.[0];
        if (f) item[key] = await resolveFileUrl(f, `playreel/${label}`);
      }
      await item.save();
      res.json(item);
    },

    remove: async (req, res) => {
      const item = await Model.findByIdAndDelete(req.params.id);
      if (!item) return res.status(404).json({ message: 'Not found' });
      res.json({ message: 'Deleted' });
    },

    like: async (req, res) => {
      const item = await Model.findById(req.params.id);
      if (!item) return res.status(404).json({ message: 'Not found' });
      item.likes = (item.likes || 0) + 1;
      await item.save();
      res.json({ likes: item.likes });
    },
  };
}

module.exports = { buildMediaController };
