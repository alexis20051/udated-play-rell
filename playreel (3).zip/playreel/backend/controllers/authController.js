const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');
const User = require('../models/User');

const sign = (id, role) =>
  jwt.sign({ id, role }, process.env.JWT_SECRET || 'devsecret', { expiresIn: '30d' });

exports.adminLogin = async (req, res) => {
  const { email, password } = req.body;
  const admin = await Admin.findOne({ email: (email || '').toLowerCase() });
  if (!admin) return res.status(401).json({ message: 'Invalid credentials' });
  const ok = await admin.matchPassword(password || '');
  if (!ok) return res.status(401).json({ message: 'Invalid credentials' });
  res.json({
    _id: admin._id,
    name: admin.name,
    email: admin.email,
    photo: admin.photo,
    role: 'admin',
    token: sign(admin._id, 'admin'),
  });
};

exports.adminProfile = async (req, res) => {
  res.json(req.user);
};

exports.updateAdminProfile = async (req, res) => {
  const admin = await Admin.findById(req.user._id);
  if (!admin) return res.status(404).json({ message: 'Not found' });
  admin.name = req.body.name || admin.name;
  admin.phone = req.body.phone || admin.phone;
  if (req.file) {
    admin.photo = `/uploads/images/${req.file.filename}`;
  } else if (req.body.photo) {
    admin.photo = req.body.photo;
  }
  await admin.save();
  res.json({ message: 'Profile updated', admin });
};

exports.changePassword = async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  const admin = await Admin.findById(req.user._id);
  if (!admin) return res.status(404).json({ message: 'Not found' });
  const ok = await admin.matchPassword(oldPassword || '');
  if (!ok) return res.status(400).json({ message: 'Old password incorrect' });
  admin.password = newPassword;
  await admin.save();
  res.json({ message: 'Password changed' });
};

exports.forgotPassword = async (req, res) => {
  const { email, newPassword } = req.body;
  const admin = await Admin.findOne({ email: (email || '').toLowerCase() });
  if (!admin) return res.status(404).json({ message: 'Admin not found' });
  if (!newPassword || newPassword.length < 6)
    return res.status(400).json({ message: 'New password too short' });
  admin.password = newPassword;
  await admin.save();
  res.json({ message: 'Password reset successfully' });
};

exports.userRegister = async (req, res) => {
  const { name, email, password } = req.body;
  const exists = await User.findOne({ email: (email || '').toLowerCase() });
  if (exists) return res.status(400).json({ message: 'Email already used' });
  const user = await User.create({ name, email, password });
  res.status(201).json({
    _id: user._id,
    name: user.name,
    email: user.email,
    role: 'user',
    token: sign(user._id, 'user'),
  });
};

exports.userLogin = async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: (email || '').toLowerCase() });
  if (!user) return res.status(401).json({ message: 'Invalid credentials' });
  const ok = await user.matchPassword(password || '');
  if (!ok) return res.status(401).json({ message: 'Invalid credentials' });
  res.json({
    _id: user._id,
    name: user.name,
    email: user.email,
    photo: user.photo,
    role: 'user',
    token: sign(user._id, 'user'),
  });
};
