const path = require('path');
const { uploadToCloudinary } = require('../config/cloudinary');

/**
 * Returns a public URL for an uploaded file.
 * Prefers Cloudinary when configured; otherwise returns the local /uploads/... path.
 */
async function resolveFileUrl(file, folder = 'playreel') {
  if (!file) return '';
  try {
    const cloudUrl = await uploadToCloudinary(file.path, folder);
    if (cloudUrl) return cloudUrl;
  } catch (_) {}
  // Compute path relative to /uploads, OS-independent
  const rel = path.relative(path.join(__dirname, '..', 'uploads'), file.path).split(path.sep).join('/');
  return `/uploads/${rel}`;
}

module.exports = { resolveFileUrl };
