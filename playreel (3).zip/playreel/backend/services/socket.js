const Chat = require('../models/Chat');

const initSocket = (io) => {
  io.on('connection', (socket) => {
    socket.on('join', ({ sessionId }) => {
      if (sessionId) socket.join(sessionId);
    });

    socket.on('admin:join', () => {
      socket.join('admins');
    });

    socket.on('chat:message', async (payload) => {
      try {
        const msg = await Chat.create({
          sessionId: payload.sessionId,
          sender: payload.sender || 'user',
          name: payload.name || 'Guest',
          text: payload.text,
        });
        io.to(payload.sessionId).emit('chat:message', msg);
        io.to('admins').emit('chat:message', msg);
      } catch (e) {
        socket.emit('chat:error', e.message);
      }
    });

    socket.on('chat:read', async ({ sessionId }) => {
      await Chat.updateMany({ sessionId, read: false }, { read: true });
      io.to(sessionId).emit('chat:read', { sessionId });
    });
  });
};

module.exports = initSocket;
