require('dotenv').config();
const connectDB = require('../config/db');
const Admin = require('../models/Admin');

(async () => {
  await connectDB();
  const email = process.env.ADMIN_EMAIL || 'admin@playreel.com';
  const password = process.env.ADMIN_PASSWORD || 'Admin@123';
  const existing = await Admin.findOne({ email });
  if (existing) {
    console.log('Admin already exists:', email);
    process.exit(0);
  }
  await Admin.create({ name: 'PlayReel Admin', email, password });
  console.log('Default admin created:', email, '/', password);
  process.exit(0);
})();
