const express = require('express');
const router = express.Router();
const upload = require('../middleware/uploadMiddleware');
const { protect } = require('../middleware/authMiddleware');
const { buildMediaController } = require('../controllers/mediaController');
const Video = require('../models/Video');

const c = buildMediaController(Video, 'videos', {
  thumbnail: { field: 'thumbnail' },
  videoUrl: { field: 'video' },
});

const fields = upload.fields([
  { name: 'thumbnail', maxCount: 1 },
  { name: 'video', maxCount: 1 },
]);

router.get('/', c.list);
router.get('/:id', c.getOne);
router.post('/:id/like', c.like);
// Users and admins can both upload videos
router.post('/', fields, c.create);
router.put('/:id', protect, fields, c.update);
router.delete('/:id', protect, c.remove);

module.exports = router;
