const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');
const c = require('../controllers/userController');

router.get('/', protect, adminOnly, c.list);
router.put('/:id/block', protect, adminOnly, c.block);
router.delete('/:id', protect, adminOnly, c.remove);

module.exports = router;
