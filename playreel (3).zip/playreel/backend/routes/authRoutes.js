const express = require('express');
const router = express.Router();
const upload = require('../middleware/uploadMiddleware');
const { protect, adminOnly } = require('../middleware/authMiddleware');
const ctrl = require('../controllers/authController');

router.post('/admin/login', ctrl.adminLogin);
router.post('/admin/forgot', ctrl.forgotPassword);
router.get('/admin/me', protect, adminOnly, ctrl.adminProfile);
router.put('/admin/profile', protect, adminOnly, upload.single('photo'), ctrl.updateAdminProfile);
router.put('/admin/password', protect, adminOnly, ctrl.changePassword);

router.post('/user/register', ctrl.userRegister);
router.post('/user/login', ctrl.userLogin);

module.exports = router;
