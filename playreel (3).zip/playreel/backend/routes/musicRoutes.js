const express = require('express');
const router = express.Router();
const upload = require('../middleware/uploadMiddleware');
const { protect } = require('../middleware/authMiddleware');
const { buildMediaController } = require('../controllers/mediaController');
const Music = require('../models/Music');

const c = buildMediaController(Music, 'music', {
  cover: { field: 'cover' },
  audioUrl: { field: 'audio' },
});

const fields = upload.fields([
  { name: 'cover', maxCount: 1 },
  { name: 'audio', maxCount: 1 },
]);

router.get('/', c.list);
router.get('/:id', c.getOne);
router.post('/:id/like', c.like);
router.post('/', fields, c.create);
router.put('/:id', protect, fields, c.update);
router.delete('/:id', protect, c.remove);

module.exports = router;
