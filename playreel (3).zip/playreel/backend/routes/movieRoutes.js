const express = require('express');
const router = express.Router();
const upload = require('../middleware/uploadMiddleware');
const { protect, adminOnly } = require('../middleware/authMiddleware');
const { buildMediaController } = require('../controllers/mediaController');
const Movie = require('../models/Movie');

const c = buildMediaController(Movie, 'movies', {
  thumbnail: { field: 'thumbnail' },
  banner: { field: 'banner' },
  videoUrl: { field: 'video' },
  trailer: { field: 'trailer' },
});

const fields = upload.fields([
  { name: 'thumbnail', maxCount: 1 },
  { name: 'banner', maxCount: 1 },
  { name: 'video', maxCount: 1 },
  { name: 'trailer', maxCount: 1 },
]);

router.get('/', c.list);
router.get('/:id', c.getOne);
router.post('/:id/like', c.like);
router.post('/', protect, adminOnly, fields, c.create);
router.put('/:id', protect, adminOnly, fields, c.update);
router.delete('/:id', protect, adminOnly, c.remove);

module.exports = router;
