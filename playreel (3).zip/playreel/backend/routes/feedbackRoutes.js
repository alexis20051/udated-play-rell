const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');
const c = require('../controllers/messageController');

router.post('/', c.create('feedback'));
router.get('/', protect, adminOnly, c.list('feedback'));
router.put('/:id/read', protect, adminOnly, c.markRead);
router.delete('/:id', protect, adminOnly, c.remove);

module.exports = router;
