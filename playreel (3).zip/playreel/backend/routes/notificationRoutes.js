const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');
const c = require('../controllers/notificationController');

router.get('/', protect, adminOnly, c.list);
router.put('/:id/read', protect, adminOnly, c.markRead);
router.put('/read-all', protect, adminOnly, c.markAllRead);

module.exports = router;
