const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');
const c = require('../controllers/chatController');

router.get('/', protect, adminOnly, c.listSessions);
router.get('/:sessionId', c.getMessages);
router.post('/', c.sendMessage);
router.put('/:sessionId/read', protect, adminOnly, c.markRead);

module.exports = router;
