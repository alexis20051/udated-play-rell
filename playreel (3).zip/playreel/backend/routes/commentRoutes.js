const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');
const c = require('../controllers/commentController');

router.get('/', c.list);
router.post('/', c.create);
router.delete('/:id', protect, adminOnly, c.remove);

module.exports = router;
