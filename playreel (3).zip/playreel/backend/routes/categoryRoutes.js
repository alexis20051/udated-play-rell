const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');
const c = require('../controllers/categoryController');

router.get('/', c.list);
router.post('/', protect, adminOnly, c.create);
router.delete('/:id', protect, adminOnly, c.remove);

module.exports = router;
