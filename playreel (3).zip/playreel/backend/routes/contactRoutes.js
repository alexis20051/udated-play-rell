const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');
const c = require('../controllers/messageController');

router.post('/', c.create('contact'));
router.get('/', protect, adminOnly, c.list('contact'));
router.put('/:id/read', protect, adminOnly, c.markRead);
router.delete('/:id', protect, adminOnly, c.remove);

module.exports = router;
