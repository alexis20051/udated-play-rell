const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');
const c = require('../controllers/dashboardController');

router.get('/stats', protect, adminOnly, c.stats);

module.exports = router;
