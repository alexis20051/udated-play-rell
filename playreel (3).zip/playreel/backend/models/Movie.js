const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, default: '' },
    category: { type: String, default: 'General' },
    genre: { type: String, default: '' },
    releaseDate: { type: Date, default: Date.now },
    thumbnail: { type: String, default: '' },
    banner: { type: String, default: '' },
    videoUrl: { type: String, default: '' },
    trailer: { type: String, default: '' },
    views: { type: Number, default: 0 },
    likes: { type: Number, default: 0 },
    featured: { type: Boolean, default: false },
    trending: { type: Boolean, default: false },
    uploadedBy: { type: String, default: 'admin' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Movie', movieSchema);
