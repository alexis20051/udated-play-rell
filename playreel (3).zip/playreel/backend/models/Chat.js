const mongoose = require('mongoose');

const chatSchema = new mongoose.Schema(
  {
    sessionId: { type: String, required: true, index: true },
    sender: { type: String, enum: ['user', 'admin'], required: true },
    name: { type: String, default: 'Guest' },
    text: { type: String, required: true },
    read: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Chat', chatSchema);
