const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, default: '' },
    thumbnail: { type: String, default: '' },
    videoUrl: { type: String, default: '' },
    category: { type: String, default: 'General' },
    tags: [{ type: String }],
    views: { type: Number, default: 0 },
    likes: { type: Number, default: 0 },
    uploadedBy: { type: String, default: 'admin' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Video', videoSchema);
