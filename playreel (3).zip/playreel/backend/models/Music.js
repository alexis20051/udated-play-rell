const mongoose = require('mongoose');

const musicSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    artist: { type: String, default: '' },
    description: { type: String, default: '' },
    cover: { type: String, default: '' },
    audioUrl: { type: String, default: '' },
    category: { type: String, default: 'General' },
    likes: { type: Number, default: 0 },
    uploadedBy: { type: String, default: 'admin' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Music', musicSchema);
