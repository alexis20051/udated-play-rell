const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema(
  {
    name: { type: String, default: 'Guest' },
    text: { type: String, required: true },
    contentType: { type: String, enum: ['movie', 'video', 'photo', 'music'], required: true },
    contentId: { type: mongoose.Schema.Types.ObjectId, required: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Comment', commentSchema);
