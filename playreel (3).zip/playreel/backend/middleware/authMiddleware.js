const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');
const User = require('../models/User');

const protect = async (req, res, next) => {
  let token;
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'devsecret');
      if (decoded.role === 'admin') {
        req.user = await Admin.findById(decoded.id).select('-password');
        req.role = 'admin';
      } else {
        req.user = await User.findById(decoded.id).select('-password');
        req.role = 'user';
      }
      if (!req.user) return res.status(401).json({ message: 'Not authorized' });
      return next();
    } catch (e) {
      return res.status(401).json({ message: 'Token invalid' });
    }
  }
  return res.status(401).json({ message: 'No token' });
};

const adminOnly = (req, res, next) => {
  if (req.role !== 'admin') return res.status(403).json({ message: 'Admin only' });
  next();
};

module.exports = { protect, adminOnly };
