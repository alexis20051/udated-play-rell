const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const uploadToCloudinary = async (filePath, folder = 'playreel', resource_type = 'auto') => {
  if (!process.env.CLOUDINARY_CLOUD_NAME) return null;
  try {
    const res = await cloudinary.uploader.upload(filePath, { folder, resource_type });
    return res.secure_url;
  } catch (e) {
    console.error('Cloudinary upload failed:', e.message);
    return null;
  }
};

module.exports = { cloudinary, uploadToCloudinary };
