import React from 'react';
import { mediaUrl } from '../services/api.js';

/**
 * Universal player — handles video, audio, image, and HTTP(S) or local /uploads URLs.
 */
export default function Player({ src, type = 'video', poster, className = '' }) {
  const url = mediaUrl(src);
  if (!url) {
    return (
      <div className={`grid place-items-center bg-black/40 rounded-2xl ${className}`}>
        <p className="text-neutral-500">No media available</p>
      </div>
    );
  }
  if (type === 'image') {
    return <img src={url} alt="" className={`w-full rounded-2xl ${className}`} />;
  }
  if (type === 'audio') {
    return <audio src={url} controls className={`w-full ${className}`} />;
  }
  return (
    <video
      src={url}
      poster={mediaUrl(poster)}
      controls
      playsInline
      className={`w-full rounded-2xl bg-black ${className}`}
    />
  );
}
