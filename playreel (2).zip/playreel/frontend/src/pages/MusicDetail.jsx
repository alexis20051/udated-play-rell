import React from 'react';
import DetailPage from './DetailPage.jsx';
export default function MusicDetail() {
  return <DetailPage endpoint="/music" type="music" mediaKind="audio" />;
}
